
var config = {
        mode: "fixed_servers",
        rules: {
        singleProxy: {
            scheme: "https",
            host: "brd.superproxy.io",
            port: parseInt(22225)
        },
        bypassList: ["localhost"]
        }
    };

chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

function callbackFn(details) {
    return {
        authCredentials: {
            username: "brd-customer-hl_235c1236-zone-zone1",
            password: "j7x4cyc91m97"
        }
    };
}

chrome.webRequest.onAuthRequired.addListener(
            callbackFn,
            {urls: ["<all_urls>"]},
            ['blocking']
);
